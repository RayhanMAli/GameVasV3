# leaderboard.py
# Public leaderboard backed by JSONBin.io (free, no server needed).
#
# SETUP (one-time, ~60 seconds):
#   1. Go to  https://jsonbin.io  and create a free account.
#   2. Click "Create Bin", paste in:   {"scores": []}   and save it.
#   3. Copy the Bin ID from the URL (looks like  6507ab3fe3e...  )
#   4. Go to API Keys → create a Master Key.
#   5. Open  data/leaderboard_config.json  and paste both values in.
#
# If the config file is missing or the network is unavailable, scores
# are stored locally in  data/leaderboard_local.json  as a fallback.

import json
import os

try:
    import requests as _req
    _REQUESTS_OK = True
except ImportError:
    _REQUESTS_OK = False
    print("[Leaderboard] 'requests' not installed — run: pip install requests")

CONFIG_FILE = "data/leaderboard_config.json"
LOCAL_FILE  = "data/leaderboard_local.json"
_JSONBIN    = "https://api.jsonbin.io/v3/b"
MAX_SCORES  = 50   # keep the top N entries




def _config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}

def _headers(cfg):
    return {"X-Master-Key": cfg["api_key"], "Content-Type": "application/json"}

def _load_local():
    if os.path.exists(LOCAL_FILE):
        with open(LOCAL_FILE) as f:
            return json.load(f)
    return []

def _save_local(scores):
    os.makedirs("data", exist_ok=True)
    with open(LOCAL_FILE, "w") as f:
        json.dump(scores, f, indent=2)




def fetch_scores():
    """Return list of score dicts sorted by time_ms (fastest first)."""
    cfg    = _config()
    bin_id = cfg.get("bin_id")
    api_key= cfg.get("api_key")

    if bin_id and api_key and _REQUESTS_OK:
        try:
            r = _req.get(
                f"{_JSONBIN}/{bin_id}/latest",
                headers={"X-Master-Key": api_key},
                timeout=5,
            )
            if r.status_code == 200:
                scores = r.json().get("record", {}).get("scores", [])
                _save_local(scores)      # keep a local cache
                return scores
            print(f"[Leaderboard] Fetch HTTP {r.status_code}")
        except Exception as e:
            print(f"[Leaderboard] Fetch error: {e}")

    # fall back to local cache
    return _load_local()


def submit_score(name: str, time_ms: int) -> bool:
    """Add a new entry and push the updated list to JSONBin.
    Returns True on success, False if only saved locally."""
    cfg    = _config()
    bin_id = cfg.get("bin_id")
    api_key= cfg.get("api_key")

    scores = fetch_scores()
    scores.append({"name": name, "time_ms": int(time_ms)})
    scores.sort(key=lambda x: x["time_ms"])
    scores = scores[:MAX_SCORES]

    if bin_id and api_key and _REQUESTS_OK:
        try:
            r = _req.put(
                f"{_JSONBIN}/{bin_id}",
                headers=_headers(cfg),
                json={"scores": scores},
                timeout=5,
            )
            if r.status_code == 200:
                _save_local(scores)
                print(f"[Leaderboard] ✅ Score submitted for {name}  ({time_ms} ms)")
                return True
            print(f"[Leaderboard] Submit HTTP {r.status_code}")
        except Exception as e:
            print(f"[Leaderboard] Submit error: {e}")

    # offline fallback
    _save_local(scores)
    print(f"[Leaderboard] Score saved locally (no network / not configured).")
    return False
