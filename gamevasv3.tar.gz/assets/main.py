import aiohttp
import asyncio
from datetime import datetime, timedelta
import json
from button import Button
import os
import webbrowser
import pygame
from pygame.locals import *
import csv
import requests  # pip install requests  (for leaderboard)

#                                              
#  LEADERBOARD CONFIG  (JSONBin.io - free tier)
#                                              
JSONBIN_MASTER_KEY = "$2a$10$ovz448pQp9yLKtACR2Xl4OrfTQnak/NxUwcLrzkdN1ublX0BRfGS6"   # e.g. "$2a$10$abc..."
JSONBIN_BIN_ID     = "69c20cf5aa77b81da912ade8"        # e.g. "64abc123..."
JSONBIN_BASE       = "https://api.jsonbin.io/v3/b"

# Default Canvas token (already in the original code)
DEFAULT_ACCESS_TOKEN = "8844~BvcXHwKvXCruykREHaFVQmrNWXXmuacNtJvWatAkvuQaKDA93LA97a6GTTR3KamT"

#                                              
#  PYGAME INIT
#                                              
pygame.init()
try:
    pygame.scrap.init()
except Exception:
    pass  # clipboard paste not available on all platforms

screen_width  = 1200
screen_height = 720

# Camera / zoom
ZOOM   = 2
VIEW_W = screen_width  // ZOOM   # 600
VIEW_H = screen_height // ZOOM   # 360
cam_x  = float(screen_width  // 2 - VIEW_W // 2)
cam_y  = float(screen_height // 2 - VIEW_H // 2)
LOOK_AHEAD  = 70    # pixels ahead of player (world space)
LERP_FACTOR = 0.09  # camera smoothing per frame

# Timer state
accumulated_ms   = 0
game_start_ticks = 0
timer_running    = False
final_time       = 0.0

# Game / screen state flags
show_score_screen  = False
show_leaderboard   = False
level_complete     = False
player_name_input  = ""
leaderboard_cache  = []

submission_scroll_offset = 0
assignment_scroll_offset = 0
duration = 0
text     = ""

#                                              
#  SCREEN + FONTS + COLORS
#                                              
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("GameVas - A Triple A Game")

bg = pygame.image.load('assets/GameVas_bg.png')

tile_size = 16
game_over = 0

font           = pygame.font.SysFont('Bauhaus 93', 25)
font_game_over = pygame.font.SysFont('Bauhaus 93', 70)
font_small     = pygame.font.SysFont('Arial', 18)

white = (255, 255, 255)
black = (0,   0,   0)

main_menu       = True
shop_menu       = False
start_game      = False
show_assignments = False
show_submissions = False


#                                              
#  TIMER HELPERS
#                                              
def start_timer():
    global game_start_ticks, timer_running
    game_start_ticks = pygame.time.get_ticks()
    timer_running    = True

def pause_timer():
    global accumulated_ms, timer_running
    if timer_running:
        accumulated_ms += pygame.time.get_ticks() - game_start_ticks
        timer_running   = False

def reset_timer():
    global accumulated_ms, timer_running
    accumulated_ms = 0
    timer_running  = False

def get_elapsed_seconds():
    ms = accumulated_ms
    if timer_running:
        ms += pygame.time.get_ticks() - game_start_ticks
    return ms / 1000.0

def format_time(seconds):
    mins = int(seconds) // 60
    secs = seconds % 60
    return f"{mins:02d}:{secs:05.2f}"


#                                              
#  LEADERBOARD FUNCTIONS
#                                              
def fetch_leaderboard():
    if JSONBIN_BIN_ID == "YOUR_BIN_ID_HERE":
        return []
    try:
        url     = f"{JSONBIN_BASE}/{JSONBIN_BIN_ID}/latest"
        headers = {"X-Master-Key": JSONBIN_MASTER_KEY, "X-Bin-Meta": "false"}
        r       = requests.get(url, headers=headers, timeout=5)
        scores  = r.json().get("scores", [])
        if not isinstance(scores, list):
            scores = []
        return sorted(scores, key=lambda x: x.get("time", 999999))[:10]
    except Exception as e:
        print(f"Leaderboard fetch error: {e}")
        return []

def submit_to_leaderboard(name, time_seconds):
    if JSONBIN_BIN_ID == "YOUR_BIN_ID_HERE":
        print("  JSONBin not configured - score saved locally only.")
        return False
    try:
        scores = fetch_leaderboard()
        scores.append({"name": name, "time": round(time_seconds, 2)})
        scores = sorted(scores, key=lambda x: x["time"])[:10]
        url     = f"{JSONBIN_BASE}/{JSONBIN_BIN_ID}"
        headers = {"Content-Type": "application/json", "X-Master-Key": JSONBIN_MASTER_KEY}
        r       = requests.put(url, json={"scores": scores}, headers=headers, timeout=5)
        return r.status_code == 200
    except Exception as e:
        print(f"Leaderboard submit error: {e}")
        return False


#                                              
#  TOKEN DIALOG  (runs before game loop)
#                                              
# --- REPLACE STARTING AT LINE 41 ---
async def show_token_dialog():
    """Displays a graphical input box to pick or enter a Canvas token."""
    font_menu = pygame.font.SysFont('Arial', 30)
    font_small = pygame.font.SysFont('Arial', 18)
    
    input_rect = pygame.Rect(screen_width // 2 - 300, 400, 600, 50)
    submit_rect = pygame.Rect(screen_width // 2 - 100, 480, 200, 50)
    use_default_rect = pygame.Rect(screen_width // 2 - 150, 250, 300, 50)
    
    user_text = ""
    clock = pygame.time.Clock()
    
    while True:
        screen.fill((30, 30, 50))
        title = font_menu.render("Canvas Access Token Required", True, (255, 255, 255))
        screen.blit(title, (screen_width // 2 - title.get_width() // 2, 100))
        
        pygame.draw.rect(screen, (70, 70, 100), use_default_rect, border_radius=10)
        def_text = font_menu.render("Use Default Token", True, (255, 255, 255))
        screen.blit(def_text, (use_default_rect.centerx - def_text.get_width() // 2, use_default_rect.centery - 15))
        
        pygame.draw.rect(screen, (255, 255, 255), input_rect, 2)
        txt_surface = font_menu.render(user_text + ("|" if (pygame.time.get_ticks() // 500) % 2 == 0 else ""), True, (255, 255, 255))
        screen.blit(txt_surface, (input_rect.x + 10, input_rect.y + 10))
        
        pygame.draw.rect(screen, (50, 150, 50), submit_rect, border_radius=10)
        sub_text = font_menu.render("Submit", True, (255, 255, 255))
        screen.blit(sub_text, (submit_rect.centerx - sub_text.get_width() // 2, submit_rect.centery - 15))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return DEFAULT_ACCESS_TOKEN
            if event.type == pygame.MOUSEBUTTONDOWN:
                if use_default_rect.collidepoint(event.pos):
                    return DEFAULT_ACCESS_TOKEN
                if submit_rect.collidepoint(event.pos) and user_text.strip():
                    return user_text.strip()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_BACKSPACE:
                    user_text = user_text[:-1]
                elif event.key == pygame.K_RETURN and user_text.strip():
                    return user_text.strip()
                else:
                    if len(user_text) < 100 and event.unicode.isprintable():
                        user_text += event.unicode

        pygame.display.update()
        await asyncio.sleep(0)  # Yield to browser
        clock.tick(60)

#                                              
#  CAMERA
#                                              
def apply_camera(player):
    global cam_x, cam_y

    look_dir  = player.last_dx  # -1, 0, or 1
    target_x  = player.rect.centerx + look_dir * LOOK_AHEAD - VIEW_W // 2
    target_y  = player.rect.centery - VIEW_H * 0.42   # slightly above centre

    cam_x += (target_x - cam_x) * LERP_FACTOR
    cam_y += (target_y - cam_y) * LERP_FACTOR
    cam_x  = max(0, min(cam_x, screen_width  - VIEW_W))
    cam_y  = max(0, min(cam_y, screen_height - VIEW_H))

    snapshot = screen.copy()
    sub_rect = pygame.Rect(int(cam_x), int(cam_y), VIEW_W, VIEW_H)
    sub_rect.clamp_ip(screen.get_rect())
    viewport = snapshot.subsurface(sub_rect)
    zoomed   = pygame.transform.scale(viewport, (screen_width, screen_height))
    screen.blit(zoomed, (0, 0))


#                                              
#  LOAD LEVEL
#                                              
def load_level(filename):
    level_data = []
    with open(filename, newline='') as csvfile:
        for row in csv.reader(csvfile, delimiter=','):
            level_data.append([int(v) for v in row])
    return level_data


#                                              
#  BUTTON IMAGES
#                                              
restart_img    = pygame.transform.scale(pygame.image.load('assets/Restart_button.png'),   (200, 100))
start_img      = pygame.transform.scale(pygame.image.load('assets/start_button.png'),     (200, 100))
quit_img       = pygame.transform.scale(pygame.image.load('assets/Quit_button.png'),      (200, 100))
coin_img       = pygame.transform.scale(pygame.image.load('assets/currency_image.png'),   (25,   25))
main_menu_img  = pygame.transform.scale(pygame.image.load('assets/main_menu_button.png'), (200, 100))
shop_img       = pygame.transform.scale(pygame.image.load('assets/shop_button.png'),      (200, 100))
assignments_img = pygame.transform.scale(pygame.image.load('assets/assignments_button.png'), (200, 100))
submissions_img = pygame.transform.scale(pygame.image.load('assets/submissions_button.png'), (200, 100))

speed_upgrade_img         = pygame.transform.scale(pygame.image.load('assets/Speed_upgrade_image.png'),   (350, 150))
Lava_Decrease_upgrade_img = pygame.transform.scale(pygame.image.load('assets/Lava_downgrade_image.png'), (350, 150))
Jump_upgrade_img          = pygame.transform.scale(pygame.image.load('assets/Jump_upgrade_image.png'),   (350, 150))


#                                              
#  SHOP + MISC
#                                              
speed_cost        = 15
lava_decrease_cost = 15
jump_cost         = 15
color             = "white"
level_num         = 1
level1_data       = load_level(f'levels/level{level_num}.csv')
toc               = False
player_speed      = 3
player_jump_height = 0.8


def draw_text(text, font, color, x, y, dur):
    screen.blit(font.render(text, True, color), (x, y))

def draw_text_list(lines, start_x, start_y, line_height=30):
    y = start_y
    for line in lines:
        screen.blit(font.render(line, True, white), (start_x, y))
        y += line_height


def set_up_shop():
    import time
    global speed_cost, lava_decrease_cost, jump_cost, main_menu, shop_menu
    global player_jump_height, player_speed, duration, text, color

    speed_upgrade_button.show()
    lava_decrease_button.show()
    jump_upgrade_button.show()
    main_menu_button.show()
    main_menu_button.draw(screen)
    speed_upgrade_button.draw(screen)
    lava_decrease_button.draw(screen)
    jump_upgrade_button.draw(screen)

    if speed_upgrade_button.is_clicked():
        if user.points >= speed_cost:
            duration       = 60
            user.points   -= speed_cost
            speed_cost    += 10
            player_speed  += 2
            text  = f"+2 Speed! | Speed now: {round(player_speed, 2)}"
            color = "green"

    if lava_decrease_button.is_clicked():
        if user.points >= lava_decrease_cost:
            duration            = 60
            user.points        -= lava_decrease_cost
            lava_decrease_cost += 10
            world.lava_speed   -= 1
            text  = f"-0.1 Lava Speed! | Lava: {round(world.lava_speed, 2)}"
            color = "orange"

    if jump_upgrade_button.is_clicked():
        if user.points >= jump_cost:
            duration           = 60
            user.points       -= jump_cost
            jump_cost         += 10
            player_jump_height -= 0.05
            text  = f"+1 Gravity! | Gravity now: {round(player_jump_height, 2)}"
            color = "blue"

    if main_menu_button.is_clicked():
        jump_upgrade_button.hide()
        lava_decrease_button.hide()
        speed_upgrade_button.hide()
        main_menu_button.hide()
        main_menu = True
        shop_menu = False

    if duration > 0:
        draw_text(text, font, color, screen_width // 3 - 15, screen_height - 50, 800)
        duration -= 1

    draw_text(f"+2 Speed Upgrade: {speed_cost} pts",          font, "green",  screen_width // 3 - 390, screen_height - 500, 0)
    draw_text(f"-0.1 Lava Speed Upgrade: {lava_decrease_cost} pts", font, "orange", screen_width // 3 - 390, screen_height - 350, 0)
    draw_text(f"-0.05 Gravity Upgrade: {jump_cost} pts",       font, "blue",   screen_width // 3 - 390, screen_height - 200, 0)


#                                              
#  PLAYER CLASS
#                                              
class Player:
    def __init__(self, x, y):
        self.load_images()
        self.reset(x, y)

    def load_images(self):
        self.image_right = pygame.transform.scale(pygame.image.load('assets/Player2.png'),    (15, 15))
        self.image_left  = pygame.transform.scale(pygame.image.load('assets/Player3.png'),    (15, 15))
        self.image_idle  = pygame.transform.scale(pygame.image.load('assets/Player1.png'),    (15, 15))
        self.dead_image  = pygame.transform.scale(pygame.image.load('assets/Player_DEAD.png'), (15, 15))
        self.image       = self.image_idle

    def reset(self, x, y):
        self.image   = self.image_idle
        self.rect    = self.image.get_rect()
        self.rect.x  = x
        self.rect.y  = y
        self.vel_y   = 0
        self.jumped  = False
        self.in_air  = True
        self.width   = self.image.get_width()
        self.height  = self.image.get_height()
        self.last_dx = 0  # used by camera look-ahead

    def update_screen(self, game_over):
        global level_num, toc, level_complete
        global accumulated_ms, game_start_ticks
        global level1_data, world

        dx, dy = 0, 0
        self.last_dx = 0  # reset each frame

        if game_over == 0:
            key = pygame.key.get_pressed()

            if key[pygame.K_LEFT]:
                dx           = -player_speed
                self.last_dx = -1
                self.image   = self.image_left
            elif key[pygame.K_RIGHT]:
                dx           = player_speed
                self.last_dx = 1
                self.image   = self.image_right
            else:
                self.image = self.image_idle

            # Jump
            if key[pygame.K_UP] and not self.jumped and not self.in_air:
                self.vel_y  = -10
                self.jumped = True
            if not key[pygame.K_UP]:
                self.jumped = False

            # Gravity
            self.vel_y += player_jump_height
            if self.vel_y > 5:
                self.vel_y = 5
            dy += self.vel_y

            # Horizontal collision
            self.rect.x += dx
            for tile in world.tile_list:
                if tile[1].colliderect(self.rect):
                    if dx > 0:
                        self.rect.right = tile[1].left
                    elif dx < 0:
                        self.rect.left  = tile[1].right

            # Vertical collision
            self.rect.y += dy
            self.in_air  = True
            for tile in world.tile_list:
                if tile[1].colliderect(self.rect):
                    if self.vel_y > 0:
                        self.rect.bottom = tile[1].top
                        self.in_air      = False
                    elif self.vel_y < 0:
                        self.rect.top    = tile[1].bottom
                    self.vel_y = 0

            # Death by lava
            if self.rect.colliderect(world.lava_rect) or toc:
                game_over = -1

            # Reach the top of the screen → level complete
            if self.rect.top <= 0:
                if level_num == 2:
                    #    Level 2 finished: trigger score screen   
                    level_complete = True
                else:
                    #    Advance to next level   
                    # Carry timer across levels
                    if timer_running:
                        accumulated_ms += pygame.time.get_ticks() - game_start_ticks
                        game_start_ticks = pygame.time.get_ticks()
                    if level_num <= 5:
                        level_num   += 1
                        level1_data  = load_level(f'levels/level{level_num}.csv')
                        world        = World(level1_data)
                        world.lava_rect.bottom = screen_height + 900  # reset lava
                        self.reset(100, screen_height - 200)

        elif game_over == -1:
            self.image = self.dead_image
            toc        = False

        screen.blit(self.image, self.rect)
        return game_over


#                                              
#  WORLD CLASS
#                                              
class World:
    def __init__(self, data):
        self.tile_list = []

        black_tile_img      = pygame.image.load('assets/black_tile.png')
        yellow_tile_img     = pygame.image.load('assets/Yellow_tile.png')
        window_tile         = pygame.image.load('assets/Window_img.png')
        red_tile_img        = pygame.image.load('assets/Red_tile.png')
        pink_tile_img       = pygame.image.load('assets/Pink_tile.png')
        light_blue_tile_img = pygame.image.load('assets/Light_blue_tile.png')
        green_tile_img      = pygame.image.load('assets/Green_tile.png')
        eye_tile_img        = pygame.image.load('assets/Eye_tile.png')
        blue_tile_img       = pygame.image.load('assets/Blue_tile.png')

        tile_map = {
            1: black_tile_img,
            2: yellow_tile_img,
            3: window_tile,
            4: red_tile_img,
            5: pink_tile_img,
            6: light_blue_tile_img,
            7: green_tile_img,
            8: eye_tile_img,
            9: blue_tile_img,
        }

        self.lava_img          = pygame.transform.scale(pygame.image.load('assets/lava.png'), (screen_width, screen_height))
        self.inverted_lava_img = pygame.transform.flip(self.lava_img, True, True)
        self.lava_image        = self.lava_img
        self.lava_rect         = self.lava_image.get_rect()
        self.lava_rect.bottom  = screen_height + 900
        self.lava_speed        = 1.0
        self.tick_counter      = 10

        for row_num, row in enumerate(data):
            for column_num, tile in enumerate(row):
                if tile in tile_map:
                    img      = pygame.transform.scale(tile_map[tile], (tile_size, tile_size))
                    img_rect = img.get_rect()
                    img_rect.x = column_num * tile_size
                    img_rect.y = row_num    * tile_size
                    self.tile_list.append((img, img_rect))

    def draw(self):
        for tile in self.tile_list:
            screen.blit(tile[0], tile[1])

    def lava_rise(self, player):
    # change 3 to ihgher number for slower lava
        if self.tick_counter % 3 == 0:
            self.lava_rect.y -= 1

        # ANIMATION LOGIC: (This was already in your code)
        if self.tick_counter % 4 == 0:
            self.lava_image = (self.inverted_lava_img
                            if self.lava_image is self.lava_img
                            else self.lava_img)
        
        self.tick_counter += 1

        # COLLISION LOGIC:
        if self.lava_rect.colliderect(player.rect):
            global toc
            toc = True
            return -1
        return 0


#                                              
#  PLAYER / WORLD / BUTTON INIT
#                                              
player = Player(100, screen_height - 200)
world  = World(level1_data)

start_button       = Button(tile_size - 1, screen_height // 6,         start_img)
quit_button        = Button(tile_size - 1, screen_height // 6 + 220,   quit_img)
assignments_button = Button(tile_size - 1, screen_height // 6 + 110,   assignments_img)
submissions_button = Button(tile_size - 1, screen_height // 6 + 330,   submissions_img)
shop_button        = Button(tile_size - 1, screen_height // 6 + 440,   shop_img)

speed_upgrade_button    = Button(460, 140, speed_upgrade_img)
lava_decrease_button    = Button(460, 300, Lava_Decrease_upgrade_img)
jump_upgrade_button     = Button(460, 460, Jump_upgrade_img)

restart_button   = Button(screen_width - 350, 250, restart_img)
main_menu_button = Button(screen_width - 350,  50, main_menu_img)


#                                              
#  CANVAS / API CONFIG
#                                              
ALLOWED_SUBMISSIONS  = ['discussion_topic', 'external_tool', 'online_upload',
                         'online_text_entry', 'online_url', 'student_annotation']
PHYSICAL_SUBMISSIONS = ['on_paper']
LATE_DAYS_LIMIT      = 30
SUBMISSION_FILE      = "data/submissions.json"
POINTS_FILE          = 'data/points.json'

ACCESS_TOKEN = DEFAULT_ACCESS_TOKEN
BASE_URL     = "https://dublinusd.instructure.com/api/v1/"
HEADERS      = {"Authorization": f"Bearer {ACCESS_TOKEN}"}


class User:
    def __init__(self, token):
        self.token       = token
        self.courses     = {}
        self.assignments = {}
        self.points      = 0


submitted = {}
user      = User(ACCESS_TOKEN)


def load_points():
    if os.path.exists(POINTS_FILE):
        with open(POINTS_FILE, 'r') as f:
            try:
                return float(f.read().strip())
            except ValueError:
                return 0.0
    return 0.0

user.points = load_points()


def save_points(points):
    with open(POINTS_FILE, 'w') as f:
        f.write(str(points))


#                                              
#  CANVAS API HELPERS
#                                              
def parse_due_date(assignment):
    if assignment.get('due_at'):
        return datetime.strptime(assignment['due_at'], "%Y-%m-%dT%H:%M:%SZ").date()
    return None

async def fetch_json(session, url, params=None):
    async with session.get(url, headers=HEADERS, params=params) as response:
        response.raise_for_status()
        if 'application/json' in response.headers.get('Content-Type', ''):
            return await response.json()
        return None

def load_previous_submissions():
    if os.path.exists(SUBMISSION_FILE):
        with open(SUBMISSION_FILE, "r") as f:
            content = f.read().strip()
            if not content:
                return {}
            return json.loads(content)
    return {}

def save_submissions(data):
    with open(SUBMISSION_FILE, "w") as f:
        json.dump(data, f, indent=2)

DEBUG = False

def has_valid_submission_type(assignment):
    sub_types = assignment.get("submission_types", [])
    return any(t in ALLOWED_SUBMISSIONS for t in sub_types)


#                                              
#  NEW: GUI COURSE SELECTION (Replaces terminal get_courses)
#                                              
async def get_courses(user):
    """GUI replacement for course selection."""
    url    = f"{BASE_URL}courses"
    params = {"enrollment_state": "active", "per_page": 1000}
    async with aiohttp.ClientSession() as session:
        try:
            courses     = await fetch_json(session, url, params=params)
            course_list = [c for c in courses if 'name' in c and 'id' in c]
        except Exception as e:
            print(f"Error fetching courses: {e}")
            course_list = []

    clock = pygame.time.Clock()
    selected = set()
    scroll_y = 0

    confirm_btn = pygame.Rect(screen_width // 2 - 100, screen_height - 80, 200, 50)
    all_btn     = pygame.Rect(screen_width - 220, 30, 180, 40)

    # Make sure screen is visible
    screen.fill((18, 18, 36))
    pygame.display.update()

    while True:
        screen.fill((18, 18, 36))
        title = font_game_over.render("Select Your Courses", True, (255, 210, 50))
        screen.blit(title, (screen_width // 2 - title.get_width() // 2, 20))

        # Select All Button
        pygame.draw.rect(screen, (70, 70, 100), all_btn, border_radius=5)
        all_txt = font_small.render("Select All", True, white)
        screen.blit(all_txt, (all_btn.centerx - all_txt.get_width() // 2, all_btn.centery - all_txt.get_height() // 2))

        # Draw course list
        course_rects = []
        for i, c in enumerate(course_list):
            r = pygame.Rect(100, 120 + i * 45 + scroll_y, screen_width - 200, 35)
            # Only draw items roughly on screen
            if 80 < r.y < screen_height - 100:
                col = (45, 160, 80) if i in selected else (50, 50, 80)
                pygame.draw.rect(screen, col, r, border_radius=5)
                pygame.draw.rect(screen, white, r, 1, border_radius=5)
                # Show number 1-9 for hotkeys
                display_text = f"{i+1}. {c['name'][:80]}"
                txt = font_small.render(display_text, True, white)
                screen.blit(txt, (r.x + 10, r.y + 7))
                course_rects.append((i, r))

        # Confirm Button
        btn_col = (255, 210, 50) if selected else (100, 100, 100)
        pygame.draw.rect(screen, btn_col, confirm_btn, border_radius=10)
        c_txt = font.render("CONFIRM", True, black)
        screen.blit(c_txt, (confirm_btn.centerx - c_txt.get_width() // 2, confirm_btn.centery - c_txt.get_height() // 2))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            
            if event.type == pygame.KEYDOWN:
                # Number keys 1-9 to select courses
                if pygame.K_1 <= event.key <= pygame.K_9:
                    idx = event.key - pygame.K_1
                    if idx < len(course_list):
                        if idx in selected: selected.remove(idx)
                        else: selected.add(idx)
                if event.key == pygame.K_RETURN and selected:
                    user.courses = {course_list[i]['id']: course_list[i]['name'] for i in selected}
                    return

            if event.type == pygame.MOUSEBUTTONDOWN:
                if confirm_btn.collidepoint(event.pos) and selected:
                    user.courses = {course_list[i]['id']: course_list[i]['name'] for i in selected}
                    return
                if all_btn.collidepoint(event.pos):
                    selected = set(range(len(course_list)))
                for i, r in course_rects:
                    if r.collidepoint(event.pos):
                        if i in selected: selected.remove(i)
                        else: selected.add(i)
                # Scrolling
                if event.button == 4: scroll_y = min(scroll_y + 30, 0)
                if event.button == 5: scroll_y -= 30

        pygame.display.update()
        clock.tick(60)

async def get_assignments(user):
    async with aiohttp.ClientSession() as session:
        for course_id in user.courses:
            url        = f"{BASE_URL}courses/{course_id}/assignments"
            params     = {"per_page": 1000}
            assignments = await fetch_json(session, url, params=params)
            filtered   = []
            if assignments:
                for a in assignments:
                    is_pub   = a.get('workflow_state') == 'published'
                    module   = a.get("lock_info", {}).get("context_module")
                    mod_pub  = not module or module.get("workflow_state") == "published"
                    unlocked = not a.get("locked_for_user", False)  # Fixed: Default to False
                    if is_pub and mod_pub and unlocked:
                        filtered.append(a)
            user.assignments[course_id] = filtered

async def get_submission_status(session, course_id, assignment_id):
    url = f"{BASE_URL}courses/{course_id}/assignments/{assignment_id}/submissions/self"
    return await fetch_json(session, url)

async def categorize_assignments(user):
    late, upcoming, physical, alternate = {}, {}, {}, {}
    cutoff = datetime.now().date() - timedelta(days=LATE_DAYS_LIMIT)
    async with aiohttp.ClientSession() as session:
        tasks   = []
        for cid, assignments in user.assignments.items():
            for a in assignments:
                tasks.append(asyncio.create_task(get_submission_status(session, cid, a['id'])))
        results = await asyncio.gather(*tasks, return_exceptions=True)
    idx = 0
    for cid, assignments in user.assignments.items():
        for assignment in assignments:
            submission = results[idx]
            idx += 1
            if isinstance(submission, Exception) or not submission:
                continue
            aid  = assignment['id']
            due  = parse_due_date(assignment)
            subs = assignment.get('submission_types', [])
            has_submitted = submission.get('workflow_state') in ('submitted', 'graded', 'pending_review')
            if has_submitted:
                submitted[aid] = (cid, assignment, submission)
                continue
            if any(t in PHYSICAL_SUBMISSIONS for t in subs):
                physical[aid] = (cid, assignment, submission)
                continue
            if not any(t in ALLOWED_SUBMISSIONS for t in subs) and due and due >= cutoff:
                alternate[aid] = (cid, assignment, submission)
                continue
            if due:
                if due >= datetime.now().date():
                    upcoming[aid] = (cid, assignment, submission)
                elif due >= cutoff:
                    late[aid]     = (cid, assignment, submission)
    return late, upcoming, physical, alternate

def display_assignments(assignments, label, user):
    print(f"\n {label}")
    if not assignments:
        return
    for aid, (cid, assignment, submission) in assignments.items():
        course   = user.courses.get(cid, 'Unknown')
        due      = parse_due_date(assignment)
        pts      = assignment.get('points_possible', 0)
        url      = assignment.get('html_url', '')
        link     = f"{assignment['name']} ({url})"
        print(f"Course: {course} |  {link} | Due: {due} | Points: {pts}")

async def check_for_submissions(user, unsubmitted):
    previous = load_previous_submissions()
    current  = {}
    new_msgs = []
    async with aiohttp.ClientSession() as session:
        # Fixed: Unpacking properly with data[0] instead of pulling out a huge tuple
        tasks   = [fetch_json(session, f"{BASE_URL}courses/{data[0]}/assignments/{aid}/submissions/self")
                   for aid, data in unsubmitted.items()]
        results = await asyncio.gather(*tasks, return_exceptions=True)
    for (aid, data), result in zip(unsubmitted.items(), results):
        if isinstance(result, Exception) or not result:
            continue
        cid, assignment, submission = data
        key       = f"{cid}_{aid}"
        new_state = result.get('workflow_state')
        old_state = previous.get(key, 'unsubmitted')
        current[key] = new_state
        if old_state == 'unsubmitted' and new_state in ('submitted', 'graded', 'pending_review'):
            pts = assignment.get('points_possible', 10)
            user.points += pts
            new_msgs.append(f" NEW Submission: {assignment['name']} | +{pts} pts | Total: {user.points}")
    previous.update(current)
    save_submissions(previous)
    if new_msgs:
        save_points(user.points)
    print("\n🔍 Checking submission status...")
    for m in new_msgs:
        print(m)
    if not new_msgs:
        print("No new submissions meeting criteria.")
    user.submission_messages = new_msgs

async def async_setup(user):
    await get_courses(user)
    
    # Simple loading screen so you know it is working
    screen.fill((18, 18, 36))
    loading = font_game_over.render("Loading Canvas Data...", True, (255, 210, 50))
    screen.blit(loading, (screen_width // 2 - loading.get_width() // 2, screen_height // 2))
    pygame.display.update()

    await get_assignments(user)
    late, upcoming, physical, alternate = await categorize_assignments(user)
    for assignments, label in [
        (physical,  "Physical Assignments"),
        (alternate, "Alternate Assignments"),
        (upcoming,  "Upcoming Assignments"),
        (late,      "Late Assignments (last 30 days)"),
    ]:
        display_assignments(assignments, label, user)
    all_assignments = {**late, **upcoming, **physical, **alternate, **submitted}
    user.assignments = all_assignments
    user.upcoming    = upcoming
    user.late        = late
    user.physical    = physical
    user.alternate   = alternate
    user.submitted   = submitted


#                                              
#  SCORE SCREEN HELPER
#                                              
def _do_submit_score():
    """Called when player clicks Submit on the score screen."""
    global show_score_screen, show_leaderboard, leaderboard_cache, player_name_input
    name = player_name_input.strip()
    if not name:
        return
    submit_to_leaderboard(name, final_time)
    leaderboard_cache   = fetch_leaderboard()
    show_score_screen   = False
    show_leaderboard    = True
    player_name_input   = ""


#                                              
#  MAIN GAME LOOP (100% UNTOUCHED FROM ORIGINAL)
#                                              
async def launch_game(user):
    global start_game, main_menu, shop_menu, show_submissions, show_assignments
    global show_score_screen, show_leaderboard, leaderboard_cache
    global player_name_input, final_time, level_complete
    global level_num, level1_data, world, game_over, toc
    global cam_x, cam_y

    clock = pygame.time.Clock()
    run   = True

    # UI rects for score / leaderboard screens (not Button objects)
    submit_rect = pygame.Rect(screen_width // 2 - 110, screen_height // 2 + 140, 220, 58)
    input_rect  = pygame.Rect(screen_width // 2 - 300, screen_height // 2 + 55,  600, 50)
    back_rect   = pygame.Rect(screen_width // 2 - 110, screen_height - 110,      220, 58)

    while run:
        clock.tick(60)
        screen.fill((0, 0, 0))
        screen.blit(bg, (0, 0))

        #    Re-init world on menu (keeps world fresh)   
        if not start_game and main_menu:
            pass  # world already set; reset only on new game start

        #                                       
        #  MAIN MENU
        #                                       
        if main_menu:
            
            quit_button.show();        quit_button.draw(screen)
            start_button.show();       start_button.draw(screen)
            shop_button.show();        shop_button.draw(screen)
            assignments_button.show(); assignments_button.draw(screen)
            submissions_button.show(); submissions_button.draw(screen)

#    ADD GAMEVAS V3 TITLE HERE   
            # Create a MUCH larger font just for the main menu title
            massive_title_font = pygame.font.SysFont('Bauhaus 93', 120)
            
            # Render the drop shadow first (Black)
            shadow_surf = massive_title_font.render("GAMEVAS V3", True, (0, 0, 0))
            title_x = (screen_width // 4 * 3) - (shadow_surf.get_width() // 2) - 200
            title_y = screen_height // 2 - (shadow_surf.get_height() // 2) -200
            screen.blit(shadow_surf, (title_x + 6, title_y + 6)) # +6 offset for bigger shadow

            # Render the main text on top (Gold)
            title_surf = massive_title_font.render("GAMEVAS V3", True, (255, 210, 50))
            screen.blit(title_surf, (title_x, title_y))
            #                                

            # Draw Points
            screen.blit(coin_img, (tile_size - 1, 13))
            draw_text('X' + str(user.points), font, white, tile_size + 30, 10, 0)
            
            # Draw Points
            screen.blit(coin_img, (tile_size - 1, 13))
            draw_text('X' + str(user.points), font, white, tile_size + 30, 10, 0)

            # Leaderboard Text Link
            lb_x, lb_y = tile_size - 1, 40
            lb_text_surf = font_small.render("View Leaderboard", True, (180, 180, 220))
            leaderboard_text_rect = screen.blit(lb_text_surf, (lb_x, lb_y))
            pygame.draw.line(screen, (180, 180, 220), (lb_x, lb_y + 18), (lb_x + lb_text_surf.get_width(), lb_y + 18), 1)

            
            # Check for text hover/click
            mouse_pos = pygame.mouse.get_pos()
            if leaderboard_text_rect.collidepoint(mouse_pos):
                lb_text_surf = font_small.render("View Leaderboard", True, (255, 210, 50))
                screen.blit(lb_text_surf, (lb_x, lb_y))
                pygame.draw.line(screen, (255, 210, 50), (lb_x, lb_y + 18), (lb_x + lb_text_surf.get_width(), lb_y + 18), 1)
                
                if pygame.mouse.get_pressed()[0] == 1:
                    leaderboard_cache = fetch_leaderboard()
                    main_menu         = False
                    show_leaderboard  = True

            if quit_button.is_clicked():
                run = False

            if start_button.is_clicked():
                # Reset everything for a fresh run
                level_num   = 1
                level1_data = load_level('levels/level1.csv')
                world       = World(level1_data)
                player.reset(100, screen_height - 200)
                world.lava_rect.bottom = screen_height + 900
                game_over  = 0
                toc        = False
                main_menu  = False
                start_game = True
                reset_timer()
                start_timer()
                # Reset camera onto player
                cam_x = float(player.rect.centerx - VIEW_W // 2)
                cam_y = float(player.rect.centery - VIEW_H // 2)

            if shop_button.is_clicked():
                import time; time.sleep(0.1)
                main_menu = False
                shop_menu = True

            if assignments_button.is_clicked():
                main_menu        = False
                show_assignments = True

            if submissions_button.is_clicked():
                main_menu         = False
                show_submissions  = True

        #                                       
        #  SHOP
        #                                       
        elif shop_menu:
            screen.blit(coin_img, (tile_size - 1, 13))
            draw_text('X' + str(user.points), font, white, tile_size + 30, 10, 0)
            set_up_shop()

        #                                       
        #  GAMEPLAY
        #                                       
        elif start_game:
            world.draw()
            screen.blit(world.lava_image, world.lava_rect)
            game_over = player.update_screen(game_over)

            if game_over == 0:
                world.lava_rise(player)

            # Pause timer on death
            if game_over == -1 and timer_running:
                pause_timer()

            # Check level-2 complete flag
            if level_complete:
                level_complete = False
                pause_timer()
                final_time  = get_elapsed_seconds()
                start_game  = False
                show_score_screen = True

            #    Apply 2x camera ZOOM (world-space only, before HUD)   
            if not show_score_screen:
                apply_camera(player)

            #    HUD (drawn unzoomed, on top of zoomed world)   
            elapsed = get_elapsed_seconds()
            draw_text(f" {format_time(elapsed)}", font, white, 10, 10, 0)
            draw_text(f"Level: {level_num}",        font, white, 10, 40, 0)
            screen.blit(coin_img, (screen_width - 80, 10))
            draw_text('X' + str(user.points), font, white, screen_width - 50, 10, 0)

            if game_over == -1:
                restart_button.show();   restart_button.draw(screen)
                main_menu_button.show(); main_menu_button.draw(screen)

                if restart_button.is_clicked():
                    player.reset(100, screen_height - 200)
                    world.lava_rect.bottom = screen_height + 900
                    game_over = 0
                    toc       = False
                    start_timer()   # resume (don't reset - death time already deducted)

                elif main_menu_button.is_clicked():
                    restart_button.hide()
                    main_menu_button.hide()
                    main_menu  = True
                    start_game = False
                    level_num  = 1
                    level1_data = load_level('levels/level1.csv')
                    world       = World(level1_data)
                    reset_timer()

        #                                       
        #  SCORE SCREEN  (level 2 completed)
        #                                       
        elif show_score_screen:
            screen.fill((18, 18, 36))

            # Trophy header
            trophy = font_game_over.render("  Level Complete!", True, (255, 210, 50))
            screen.blit(trophy, (screen_width // 2 - trophy.get_width() // 2, 90))

            # Time
            time_surf = font.render(f"Your time:  {format_time(final_time)}", True, white)
            screen.blit(time_surf, (screen_width // 2 - time_surf.get_width() // 2, 210))

            # Name prompt
            prompt = font.render("Enter your name for the leaderboard:", True, (180, 180, 220))
            screen.blit(prompt, (screen_width // 2 - prompt.get_width() // 2, screen_height // 2))

            # Input box
            pygame.draw.rect(screen, (50, 50, 90), input_rect, border_radius=8)
            pygame.draw.rect(screen, white, input_rect, 2, border_radius=8)
            cursor = "|" if (pygame.time.get_ticks() // 500) % 2 == 0 else ""
            name_surf = font.render(player_name_input + cursor, True, white)
            screen.blit(name_surf, (input_rect.x + 10,
                                    input_rect.centery - name_surf.get_height() // 2))

            # Submit button
            btn_color = (45, 160, 80) if player_name_input.strip() else (60, 60, 60)
            pygame.draw.rect(screen, btn_color, submit_rect, border_radius=10)
            pygame.draw.rect(screen, white, submit_rect, 2, border_radius=10)
            sub_surf = font.render("Submit Score", True, white)
            screen.blit(sub_surf, (submit_rect.centerx - sub_surf.get_width() // 2,
                                   submit_rect.centery - sub_surf.get_height() // 2))

            # Hint
            hint = font_small.render("(Ctrl+V to paste    Enter to confirm)", True, (130, 130, 160))
            screen.blit(hint, (screen_width // 2 - hint.get_width() // 2, screen_height // 2 + 215))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        player_name_input = player_name_input[:-1]
                    elif event.key == pygame.K_RETURN and player_name_input.strip():
                        _do_submit_score()
                    elif event.key == pygame.K_v and (pygame.key.get_mods() & pygame.KMOD_CTRL):
                        try:
                            cb = pygame.scrap.get(pygame.SCRAP_TEXT)
                            if cb:
                                player_name_input += cb.decode('utf-8', errors='ignore').strip()
                        except Exception:
                            pass
                    else:
                        if len(player_name_input) < 20:
                            player_name_input += event.unicode
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if submit_rect.collidepoint(event.pos) and player_name_input.strip():
                        _do_submit_score()

        #                                       
        #  LEADERBOARD SCREEN
        #                                       
        elif show_leaderboard:
            screen.fill((18, 18, 36))

            title_s = font_game_over.render(" Leaderboard", True, (255, 210, 50))
            screen.blit(title_s, (screen_width // 2 - title_s.get_width() // 2, 40))

            if JSONBIN_BIN_ID == "YOUR_BIN_ID_HERE":
                msg = font.render("Leaderboard not configured - see JSONBIN_BIN_ID in main.py", True, (200, 100, 100))
                screen.blit(msg, (screen_width // 2 - msg.get_width() // 2, 200))
            elif not leaderboard_cache:
                msg = font.render("No scores yet - be the first to finish!", True, (180, 180, 220))
                screen.blit(msg, (screen_width // 2 - msg.get_width() // 2, 200))
            else:
                MEDAL = {0: "Gold", 1: "Silver", 2: "Bronze"}
                MEDAL_COLOR = {
                    0: (255, 210,  50),
                    1: (192, 192, 192),
                    2: (205, 127,  50),
                }
                for i, entry in enumerate(leaderboard_cache[:10]):
                    name      = entry.get('name', 'Unknown')
                    t         = entry.get('time', 0)
                    medal     = MEDAL.get(i, f"#{i+1}")
                    col       = MEDAL_COLOR.get(i, white)
                    row_text  = font.render(f"{medal}  {name:<20}  {format_time(t)}", True, col)
                    screen.blit(row_text, (screen_width // 2 - row_text.get_width() // 2,
                                           130 + i * 48))

            # Back button
            pygame.draw.rect(screen, (80, 80, 180), back_rect, border_radius=10)
            pygame.draw.rect(screen, white, back_rect, 2, border_radius=10)
            back_surf = font.render("Main Menu", True, white)
            screen.blit(back_surf, (back_rect.centerx - back_surf.get_width() // 2,
                                    back_rect.centery - back_surf.get_height() // 2))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if back_rect.collidepoint(event.pos):
                        show_leaderboard = False
                        main_menu        = True

        #                                       
        #  ASSIGNMENTS
        #                                       
        elif show_assignments:
            # Fixed: Use the global variable so it doesn't reset to 0 every frame
            global assignment_scroll_offset
            scroll_speed  = 30
            main_menu_button.x = screen_width - main_menu_button.image.get_width() - 20
            main_menu_button.y = 20
            draw_text("Assignments", font, white, 20, 20, 0)
            main_menu_button.draw(screen)
            main_menu_button.show()

            categories = [
                (user.physical,  "Physical Assignments"),
                (user.alternate, "Alternate Assignments"),
                (user.upcoming,  "Upcoming Assignments"),
                (user.late,      "Late Assignments (last 30 days)"),
            ]
            y_start          = 80 + assignment_scroll_offset
            assignment_rects = []
            
            for assignments, label in categories:
                draw_text(label, font, white, 20, y_start, 0)
                y_start += 30
                if assignments:
                    for aid, (cid, assignment, submission) in assignments.items():
                        name     = assignment['name']
                        due      = parse_due_date(assignment)
                        txt      = f" {name} | Due: {due}"
                        txt_surf = font.render(txt, True, white)
                        rect     = screen.blit(txt_surf, (20, y_start))
                        assignment_rects.append((rect, assignment.get("html_url", "")))
                        y_start += 25
                else:
                    draw_text("No assignments found.", font, (200, 200, 200), 40, y_start, 0)
                    y_start += 25
                y_start += 10

            if main_menu_button.is_clicked():
                show_assignments = False
                main_menu        = True

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 4:
                        assignment_scroll_offset = min(assignment_scroll_offset + scroll_speed, 0)
                    elif event.button == 5:
                        assignment_scroll_offset -= scroll_speed
                    pos = event.pos
                    for rect, url in assignment_rects:
                        if rect.collidepoint(pos) and url:
                            webbrowser.open(url)

        #                                       
        #  SUBMISSIONS
        #                                       
        elif show_submissions:
            global submission_scroll_offset
            scroll_speed = 30
            y_offset     = submission_scroll_offset

            draw_text("Submission Updates", font, white, 20, 20, 0)
            main_menu_button.x = screen_width - main_menu_button.image.get_width() - 20
            main_menu_button.y = 20
            main_menu_button.draw(screen)
            main_menu_button.show()

            if not hasattr(user, 'submission_messages_checked') or not user.submission_messages_checked:
                await check_for_submissions(user, user.assignments)
                user.submission_messages_checked = True

            new_msgs = getattr(user, 'submission_messages', [])
            y = 80 + y_offset
            if new_msgs:
                for msg in new_msgs:
                    draw_text_list([msg], 20, y, line_height=25)
                    y += 25
            else:
                draw_text("No new submissions.", font, white, 20, 80 + y_offset, 0)

            if main_menu_button.is_clicked():
                show_submissions = False
                main_menu        = True
                user.submission_messages_checked = False
                submission_scroll_offset = 0

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 4:
                        submission_scroll_offset = min(submission_scroll_offset + scroll_speed, 0)
                    elif event.button == 5:
                        submission_scroll_offset -= scroll_speed

        #    Catch-all quit events   
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        pygame.display.update()
        await asyncio.sleep(0)

    pygame.quit()


#                                              
#  ASYNC MAIN (TERMINAL MENU REMOVED!)
#                                              
async def main():
    # 1. Shows GUI loading screen and fetches Canvas data
    await async_setup(user)

    # 2. Skips the old terminal menu completely and goes straight to play
    await launch_game(user)


#                                              
#  ENTRY POINT
#                                              
# --- REPLACE EVERYTHING FROM LINE 953 TO THE END ---
async def main():
    global ACCESS_TOKEN, HEADERS
    
    # Run the dialog inside the async loop
    chosen_token = await show_token_dialog()
    
    ACCESS_TOKEN = chosen_token
    HEADERS = {"Authorization": f"Bearer {ACCESS_TOKEN}"}
    user.token = chosen_token

    # 1. Shows GUI loading screen and fetches Canvas data
    await async_setup(user)

    # 2. Skips the old terminal menu completely and goes straight to play
    await launch_game(user)

if __name__ == "__main__":
    asyncio.run(main())