import pygame
import csv

pygame.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 1200, 720
TILE_SIZE = 16
ROWS, COLUMNS = SCREEN_HEIGHT // TILE_SIZE, SCREEN_WIDTH // TILE_SIZE

# Setup screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Level Editor")

# Load background
bg = pygame.image.load('assets/GameVas_bg.png')

# Initialize level grid
level_data = [[0] * COLUMNS for _ in range(ROWS)]
current_tile = 1  # Default tile selection

# Tile images dictionary for easy access
tile_images = {
    1: 'assets/black_tile.png',
    2: 'assets/Yellow_tile.png',
    3: 'assets/Window_img.png',
    4: 'assets/Red_tile.png',
    5: 'assets/Pink_tile.png',
    6: 'assets/Light_blue_tile.png',
    7: 'assets/Green_tile.png',
    8: 'assets/Eye_tile.png',
    9: 'assets/Blue_tile.png'
}
tile_surfaces = {key: pygame.image.load(img) for key, img in tile_images.items()}

class World:
    def __init__(self, data):
        self.data = data

    def draw(self):
        for y, row in enumerate(self.data):
            for x, tile in enumerate(row):
                if tile in tile_surfaces:
                    screen.blit(pygame.transform.scale(tile_surfaces[tile], (TILE_SIZE, TILE_SIZE)), (x * TILE_SIZE, y * TILE_SIZE))

def save_level(filename):
    with open(filename, 'w', newline='') as csvfile:
        csv.writer(csvfile).writerows(level_data)

world = World(level_data)
mouse_pressed = False

# Main loop
run = True
while run:
    screen.fill((0, 0, 0))
    screen.blit(bg, (0, 0))
    world.draw()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_s:  # Press 'S' to save
                save_level('level2.csv')
            elif pygame.K_1 <= event.key <= pygame.K_9:  # Number keys select tile type
                current_tile = event.key - pygame.K_0

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pressed = True

        if event.type == pygame.MOUSEBUTTONUP:
            mouse_pressed = False

        if mouse_pressed:  # Continuous drawing while mouse is held
            x, y = pygame.mouse.get_pos()
            x, y = x // TILE_SIZE, y // TILE_SIZE
            if pygame.mouse.get_pressed()[0]:  # Left mouse button
                try:
                    level_data[y][x] = current_tile
                except IndexError:
                    continue
            elif pygame.mouse.get_pressed()[2]:  # Right mouse button
                try:
                    level_data[y][x] = 0  # Reset tile
                except IndexError:
                    continue
    pygame.display.update()

pygame.quit()