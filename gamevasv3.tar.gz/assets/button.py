import pygame

class Button:
    def __init__(self, x, y, image, scale=1):
        """Initializes button properties, including position, image, and scale."""
        # Scale the image if a scale factor is provided
        width = image.get_width()
        height = image.get_height()
        self.image = pygame.transform.scale(image, (int(width * scale), int(height * scale)))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.clicked = False  # Track if the button was clicked
        self.visible = True   # Track if the button is visible

    def draw(self, surface):
        """Draws the button on the given surface if visible."""
        if self.visible:  # Only draw if the button is visible
            surface.blit(self.image, (self.rect.x, self.rect.y))

    def is_clicked(self):
        """Checks if the button is clicked and returns True if clicked."""
        action = False
        if self.visible:  # Only check clicks if the button is visible
            mouse_pos = pygame.mouse.get_pos()
            mouse_pressed = pygame.mouse.get_pressed()

            # Check if mouse is over the button and the left click is pressed
            if self.rect.collidepoint(mouse_pos):
                if mouse_pressed[0] == 1 and not self.clicked:
                    self.clicked = True
                    action = True  # Mark the button as clicked

            # Reset clicked state when mouse button is released
            if mouse_pressed[0] == 0:
                self.clicked = False

        return action

    def show(self):
        """Makes the button visible."""
        self.visible = True

    def hide(self):
        """Makes the button invisible."""
        self.visible = False
